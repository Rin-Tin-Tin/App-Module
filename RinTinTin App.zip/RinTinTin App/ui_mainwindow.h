/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *rotate_left_button;
    QPushButton *rotate_right_button;
    QPushButton *forward_button;
    QPushButton *back_button;
    QLabel *image;
    QLabel *map;
    QPushButton *move_right_button;
    QPushButton *move_left_button;
    QPushButton *rotate_right_button_2;
    QPushButton *rotate_right_button_3;
    QLabel *label;
    QLabel *label_2;
    QPushButton *rotate_left_button_2;
    QPushButton *rotate_right_button_4;
    QTextEdit *ip_text_field;
    QPushButton *connect_button;
    QLabel *label_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1202, 621);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("QWidget {\n"
"	background-color: #FFFFFF\n"
"}"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        rotate_left_button = new QPushButton(centralwidget);
        rotate_left_button->setObjectName("rotate_left_button");
        rotate_left_button->setGeometry(QRect(40, 380, 60, 60));
        rotate_left_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/Icons/right-arrow-black-triangle - left.png"), QSize(), QIcon::Normal, QIcon::Off);
        rotate_left_button->setIcon(icon);
        rotate_left_button->setIconSize(QSize(50, 50));
        rotate_right_button = new QPushButton(centralwidget);
        rotate_right_button->setObjectName("rotate_right_button");
        rotate_right_button->setGeometry(QRect(180, 380, 60, 60));
        rotate_right_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/Icons/right-arrow-black-triangle - right.png"), QSize(), QIcon::Normal, QIcon::Off);
        rotate_right_button->setIcon(icon1);
        rotate_right_button->setIconSize(QSize(50, 50));
        forward_button = new QPushButton(centralwidget);
        forward_button->setObjectName("forward_button");
        forward_button->setGeometry(QRect(110, 320, 60, 60));
        forward_button->setAutoFillBackground(false);
        forward_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/Icons/right-arrow-black-triangle - up.png"), QSize(), QIcon::Normal, QIcon::Off);
        forward_button->setIcon(icon2);
        forward_button->setIconSize(QSize(50, 50));
        back_button = new QPushButton(centralwidget);
        back_button->setObjectName("back_button");
        back_button->setGeometry(QRect(110, 440, 60, 60));
        back_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/Icons/right-arrow-black-triangle - down.png"), QSize(), QIcon::Normal, QIcon::Off);
        back_button->setIcon(icon3);
        back_button->setIconSize(QSize(50, 50));
        image = new QLabel(centralwidget);
        image->setObjectName("image");
        image->setGeometry(QRect(10, 10, 480, 270));
        image->setStyleSheet(QString::fromUtf8("QLabel QLabel {\n"
"	font-weight: 580;\n"
"}"));
        image->setFrameShape(QFrame::StyledPanel);
        image->setLineWidth(3);
        image->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        image->setWordWrap(false);
        image->setMargin(-6);
        map = new QLabel(centralwidget);
        map->setObjectName("map");
        map->setGeometry(QRect(570, 20, 341, 301));
        map->setBaseSize(QSize(1000, 1000));
        map->setAutoFillBackground(false);
        map->setStyleSheet(QString::fromUtf8(""));
        map->setFrameShape(QFrame::StyledPanel);
        map->setFrameShadow(QFrame::Plain);
        map->setLineWidth(3);
        map->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        move_right_button = new QPushButton(centralwidget);
        move_right_button->setObjectName("move_right_button");
        move_right_button->setGeometry(QRect(200, 500, 61, 51));
        move_right_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/icons/Icons/right-arrow-black-double-triangle.png"), QSize(), QIcon::Normal, QIcon::Off);
        move_right_button->setIcon(icon4);
        move_right_button->setIconSize(QSize(50, 50));
        move_left_button = new QPushButton(centralwidget);
        move_left_button->setObjectName("move_left_button");
        move_left_button->setGeometry(QRect(20, 500, 61, 51));
        move_left_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/icons/Icons/leftarrow-black-double-triangle.png"), QSize(), QIcon::Normal, QIcon::Off);
        move_left_button->setIcon(icon5);
        move_left_button->setIconSize(QSize(50, 50));
        rotate_right_button_2 = new QPushButton(centralwidget);
        rotate_right_button_2->setObjectName("rotate_right_button_2");
        rotate_right_button_2->setGeometry(QRect(280, 350, 61, 51));
        rotate_right_button_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/icons/Icons/reset.png"), QSize(), QIcon::Normal, QIcon::Off);
        rotate_right_button_2->setIcon(icon6);
        rotate_right_button_2->setIconSize(QSize(50, 50));
        rotate_right_button_3 = new QPushButton(centralwidget);
        rotate_right_button_3->setObjectName("rotate_right_button_3");
        rotate_right_button_3->setGeometry(QRect(280, 430, 61, 51));
        rotate_right_button_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/icons/Icons/cancel.png"), QSize(), QIcon::Normal, QIcon::Off);
        rotate_right_button_3->setIcon(icon7);
        rotate_right_button_3->setIconSize(QSize(50, 50));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(219, 20, 61, 21));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	color: black;\n"
"	font-weight: 580;\n"
"}"));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(571, 21, 61, 21));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	color: black;\n"
"	font-weight: 580;\n"
"}"));
        label_2->setAlignment(Qt::AlignCenter);
        rotate_left_button_2 = new QPushButton(centralwidget);
        rotate_left_button_2->setObjectName("rotate_left_button_2");
        rotate_left_button_2->setGeometry(QRect(62, 330, 31, 31));
        rotate_left_button_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        rotate_left_button_2->setIcon(icon);
        rotate_left_button_2->setIconSize(QSize(50, 50));
        rotate_right_button_4 = new QPushButton(centralwidget);
        rotate_right_button_4->setObjectName("rotate_right_button_4");
        rotate_right_button_4->setGeometry(QRect(190, 330, 31, 31));
        rotate_right_button_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	border: none\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: #f2f2f2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: #d9d9d9;\n"
"}"));
        rotate_right_button_4->setIcon(icon1);
        rotate_right_button_4->setIconSize(QSize(50, 50));
        ip_text_field = new QTextEdit(centralwidget);
        ip_text_field->setObjectName("ip_text_field");
        ip_text_field->setGeometry(QRect(390, 430, 131, 21));
        ip_text_field->setStyleSheet(QString::fromUtf8("QTextEdit {\n"
"	color: black;\n"
"}"));
        connect_button = new QPushButton(centralwidget);
        connect_button->setObjectName("connect_button");
        connect_button->setGeometry(QRect(420, 460, 80, 24));
        connect_button->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	color: black;\n"
"	font-weight: 580;\n"
"}"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(390, 400, 131, 21));
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	color: black;\n"
"	font-weight: 580;\n"
"}"));
        label_4->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralwidget);
        rotate_left_button->raise();
        rotate_right_button->raise();
        forward_button->raise();
        back_button->raise();
        image->raise();
        map->raise();
        move_right_button->raise();
        move_left_button->raise();
        rotate_right_button_2->raise();
        rotate_right_button_3->raise();
        label_2->raise();
        label->raise();
        rotate_left_button_2->raise();
        rotate_right_button_4->raise();
        ip_text_field->raise();
        connect_button->raise();
        label_4->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1202, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        rotate_left_button->setText(QString());
        rotate_right_button->setText(QString());
        forward_button->setText(QString());
        back_button->setText(QString());
        image->setText(QString());
        map->setText(QString());
        move_right_button->setText(QString());
        move_left_button->setText(QString());
        rotate_right_button_2->setText(QString());
        rotate_right_button_3->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Camera", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Map", nullptr));
        rotate_left_button_2->setText(QString());
        rotate_right_button_4->setText(QString());
        connect_button->setText(QCoreApplication::translate("MainWindow", "CONNECT", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "IP ADDRESS", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
